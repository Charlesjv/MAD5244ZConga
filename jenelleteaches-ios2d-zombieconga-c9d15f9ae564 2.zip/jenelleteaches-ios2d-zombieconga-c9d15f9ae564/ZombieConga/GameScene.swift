//
//  GameScene.swift
//  ZombieConga
//
//  Created by Parrot on 2019-01-29.
//  Copyright © 2019 Parrot. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
   
    // Make zombie global, so other functions can access it
    var zombie = SKSpriteNode()
    var grandma = SKSpriteNode()
    
    var score = 0
    var scoreLabel = SKLabelNode()
    
    var lifeLabel = SKLabelNode()
    var lives = 100
 
    var mouseX:CGFloat = 0
    var mouseY:CGFloat = 0
    
    var cat = SKSpriteNode()
    
    //
    
    // Movement variables
    var zombieMovingLeft:Bool = false;
    var zombieMovingRight:Bool = true;
    
    override func didMove(to view: SKView) {
        // Set the background color of the app
        
        self.zombie = SKSpriteNode(imageNamed: "zombie1")
        self.zombie.position = CGPoint(x:600,y:900)
        addChild(zombie)
        //grandma
        self.grandma = SKSpriteNode(imageNamed: "enemy")
        self.grandma.position = CGPoint(x:size.width-300,y: 800)
        addChild(grandma)
        
        self.lifeLabel = SKLabelNode(text: "Lives: \(lives)")
        self.lifeLabel.position = CGPoint(x:400,y:500)
        self.lifeLabel.fontName = "Avenir"
        self.lifeLabel.fontSize = 100
        self.addChild(lifeLabel)
        
        //Make a cat
   
        
        
        // Generate a random x position
        
        
        // Score label
        self.scoreLabel = SKLabelNode(text: "Score: \(score)")
        self.scoreLabel.position = CGPoint(x:900,y:500)
        self.scoreLabel.fontName = "Avenir"
        self.scoreLabel.fontSize = 100
        self.addChild(scoreLabel)
        
        
      
        
        self.backgroundColor = SKColor.black;
        
        // -----------------------------
        // Add a background to the game
        // -----------------------------
        // Add a background image
        let bg = SKSpriteNode(imageNamed:"background1")
        // Set position of background to middle of screen
        bg.position = CGPoint(x: size.width/2, y: size.height/2)
        
        // Force the background image to always be at the back
        bg.zPosition = -1

        // Finally, add the background to the Scene Graph
        addChild(bg)
        
        
        
        
        let move1 = SKAction.move(to: CGPoint(x: size.width/2,y: 400), duration: 5)
           let move2 = SKAction.move(to: CGPoint(x: 100,y: size.height/2), duration: 5)
           let move3 = SKAction.move(to: CGPoint(x: size.width/2 ,y:  400), duration: 5)
           let move4 = SKAction.move(to: CGPoint(x: size.width - 100,y: size.height/2), duration: 5)
        let animationSequence = SKAction.sequence([move1,move2,move3,move4])
        let foreverAnimation = SKAction.repeatForever(animationSequence)
        
        self.grandma.run(foreverAnimation)
        // -----------------------------
        // Add a zombie to the game
        // -----------------------------
      
    }
    
    var num = 0
    
    override func update(_ currentTime: TimeInterval) {
//        self.zombieX = self.zombie.position.x
//        self.zombieY = self.zombie.position.y
        
        
        num += 1
        
        if(num % 120 == 0){
            spawnCat()
        }
        
        
//          spawnCat()
        
        self.moveZombie(mouseX: self.mouseX, mouseY: self.mouseY)
        // Remember:  The game loop is:
        //      - updatePositions
        //      - drawPositions
        //      - setFPS
        // In IOS, the update() function == updatePositions() function from Android game template

        
        if(self.zombie.frame.intersects(self.grandma.frame)){
            
            if(lives < 0){
                loser()
            }
            
            print("collision")
            self.lives = self.lives-1
            self.lifeLabel.text = "Lives: \(lives)"
            
            
            
            //SHOW LOSE SCREEN
           
        }
        
        
        
        
        //Detect collision betweeen cat and zombie
        
        // if the player is touching the cat, then remove the cat and increase the score
        for (index, cat) in self.cats.enumerated(){
            
            if(self.zombie.frame.intersects(cat.frame)){
                self.score = self.score + 1
                self.scoreLabel.text = "Score: \(self.score)"
                cat.removeFromParent()
                self.cats.remove(at: index)
                
            }
            
        }
        
        
        
        
        // --------------------------
        // Make zombie bounce off left and right walls
        // --------------------------
        // get x-position of right side of screen
       
        // get current x-position of zombie
   
//
//        if (self.zombieMovingLeft == true) {
//            zombieX = self.zombie.position.x - 10;
//
//            if (zombieX <= 0) {
//                // bounce off left wall
//                self.zombieMovingRight = true;
//                self.zombieMovingLeft = false;
//
//            }
//        }
//
//        if (self.zombieMovingRight == true) {
//            zombieX = self.zombie.position.x + 10;
//
//            if (zombieX >= screenRightSide) {
//                // bounce off right wall
//                self.zombieMovingLeft = true
//                self.zombieMovingRight = false
//            }
//        }
//
//
//        self.zombie.position = CGPoint(x: zombieX, y: self.zombie.position.y)
//    }
    }
    func loser(){
        
        let loseScene = LoseScreen(size:self.size)
        let transitionEffect = SKTransition.flipVertical(withDuration: 2)
        self.view?.presentScene(loseScene,transition:transitionEffect)
    }
    
    var cats:[SKSpriteNode] = []
    
    
    func spawnCat(){
        
 
        self.cat = SKSpriteNode(imageNamed: "cat")
        let randomXPos = CGFloat.random(in: 0...size.width)
        let randomYPos = CGFloat.random(in: 0...size.height)
        self.cat.position = CGPoint(x:randomXPos,y: randomYPos)
        
        addChild(self.cat)
        
        self.cats.append(cat)
        
    }
    
    
    // MARK: Detect when user taps the screen
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        // get the first "tap" on the screen
        let touch = touches.first
        let touchLocation = touch!.location(in: self)
        print("User tapped screen at: \(touchLocation.x.rounded()),\(touchLocation.y.rounded())")
        
        self.mouseX = touchLocation.x.rounded()
        self.mouseY = touchLocation.y.rounded()
        
        if (touch == nil) {
            // if for some reason the "tap" return as null, then exit
            return
        }
        
   
    }
    
    
    
    func moveZombie(mouseX:CGFloat, mouseY:CGFloat){
        
        var a:CGFloat  = ( mouseX -  self.zombie.position.x )
        var b:CGFloat = (  mouseY -  self.zombie.position.y)
        var distance:CGFloat = sqrt((a*a) + (b*b))
        
        // 2. calculate the "rate" to move
        var xn:CGFloat = (a / distance)
        var yn:CGFloat = (b / distance)
        
        // 3. move the bullet
        self.zombie.position.x = self.zombie.position.x + (xn * 15)
        self.zombie.position.y = self.zombie.position.y + (yn * 15)
        
        
        
    }
    
}
